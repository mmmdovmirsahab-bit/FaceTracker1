package com.facetrack.camera

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sign

/** Output video aspect (width / height). All recording sizes are 9:16 portrait. */
const val OUT_ASPECT = 9f / 16f

data class TrackSettings(
    val enabled: Boolean = true,
    val sensitivity: Float = 0.6f, // 0..1  higher = follows faster
    val smoothing: Float = 0.5f,   // 0..1  higher = calmer, slower motion
    val strength: Float = 0.5f,    // 0..1  maximum zoom-in (1x .. 2.5x)
    val margin: Float = 0.5f       // 0..1  higher = more space around the face
)

/** Crop rectangle in normalized, upright (display-oriented, unmirrored) source coordinates. */
data class Crop(val x0: Float, val y0: Float, val w: Float, val h: Float)

/** Face box in normalized upright source coordinates. */
data class FaceBox(val id: Int?, val cx: Float, val cy: Float, val w: Float, val h: Float)

enum class TrackState { FOUND, SEARCHING, PAUSED }

data class Snapshot(val state: TrackState, val face: FaceBox?, val crop: Crop)

/**
 * Turns face detections into a smooth crop. Detections arrive at ~15-30 Hz from the analyzer,
 * nextCrop() is called for every rendered frame by the GL thread, so motion stays smooth.
 */
class FaceTracker {
    @Volatile var settings = TrackSettings()
    @Volatile var frameAspect = OUT_ASPECT   // upright source width / height

    private val lock = Any()
    private var curCx = 0.5f
    private var curCy = 0.5f
    private var curH = 1f
    private var tgtCx = 0.5f
    private var tgtCy = 0.5f
    private var tgtH = 1f
    private var selId: Int? = null
    private var lastFace: FaceBox? = null
    private var lastSeenMs = -1_000_000L
    private var lastNs = 0L
    private var lastCrop = Crop(0f, 0f, 1f, 1f)

    private companion object {
        const val HOLD_MS = 1500L     // keep last target this long after face is lost
        const val LOST_MS = 1500L     // don't switch to a different face during this window
        const val HEADROOM = 0.06f    // crop centre sits slightly below face centre
    }

    private fun maxH() = min(1f, frameAspect / OUT_ASPECT)
    private fun maxZoom(s: TrackSettings) = 1f + s.strength * 1.5f

    fun onFaces(faces: List<FaceBox>, nowMs: Long) {
        synchronized(lock) {
            if (faces.isEmpty()) return
            val f = choose(faces, nowMs) ?: return
            selId = f.id
            lastFace = f
            lastSeenMs = nowMs
            val s = settings
            val hMax = maxH()
            val hMin = hMax / maxZoom(s)
            val faceFrac = 0.42f - 0.24f * s.margin
            val want = (f.h / faceFrac).coerceIn(hMin, hMax)
            if (abs(want - tgtH) / tgtH > 0.12f) tgtH = want   // hysteresis: no jittery zoom
            tgtCx = f.cx
            tgtCy = f.cy + HEADROOM * tgtH
        }
    }

    private fun choose(faces: List<FaceBox>, nowMs: Long): FaceBox? {
        val id = selId
        if (id != null) faces.firstOrNull { it.id == id }?.let { return it }
        val last = lastFace
        if (last != null && nowMs - lastSeenMs < LOST_MS) {
            val near = faces.minByOrNull { hypot(it.cx - last.cx, it.cy - last.cy) }
            return if (near != null && hypot(near.cx - last.cx, near.cy - last.cy) < 0.25f) near else null
        }
        return faces.maxByOrNull { it.w * it.h }
    }

    private fun follow(cur: Float, tgt: Float, tau: Float, dt: Float, dead: Float, maxSpeed: Float): Float {
        val err = tgt - cur
        val a = abs(err)
        if (a <= dead) return cur
        val eff = (a - dead) * sign(err)
        val step = (eff * (1f - exp(-dt / tau))).coerceIn(-maxSpeed * dt, maxSpeed * dt)
        return cur + step
    }

    fun nextCrop(nowNs: Long): Crop = synchronized(lock) {
        val nowMs = nowNs / 1_000_000L
        val dt = if (lastNs == 0L) 0.033f else ((nowNs - lastNs) / 1e9f).coerceIn(0.001f, 0.1f)
        lastNs = nowNs
        val s = settings
        val hMax = maxH()
        val hMin = hMax / maxZoom(s)
        if (!s.enabled || nowMs - lastSeenMs > HOLD_MS) {
            tgtCx = 0.5f; tgtCy = 0.5f; tgtH = hMax
        }
        tgtH = tgtH.coerceIn(hMin, hMax)
        val tau = (1.0f - 0.85f * s.sensitivity) * (0.6f + 1.4f * s.smoothing)
        curCx = follow(curCx, tgtCx, tau, dt, 0.02f * curH, 1.2f)
        curCy = follow(curCy, tgtCy, tau, dt, 0.02f * curH, 1.2f)
        curH = follow(curH, tgtH, tau * 1.6f, dt, 0.01f, 0.6f).coerceIn(hMin, hMax)
        val h = curH
        val w = min(1f, h * OUT_ASPECT / frameAspect)
        val cx = curCx.coerceIn(w / 2f, 1f - w / 2f)
        val cy = curCy.coerceIn(h / 2f, 1f - h / 2f)
        lastCrop = Crop(cx - w / 2f, cy - h / 2f, w, h)
        lastCrop
    }

    fun snapshot(nowMs: Long): Snapshot = synchronized(lock) {
        val recent = nowMs - lastSeenMs < 400
        val state = when {
            !settings.enabled -> TrackState.PAUSED
            recent -> TrackState.FOUND
            else -> TrackState.SEARCHING
        }
        Snapshot(state, if (recent && settings.enabled) lastFace else null, lastCrop)
    }
}
