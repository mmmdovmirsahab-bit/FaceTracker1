package com.facetrack.camera

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.min

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

class RecordButton(ctx: Context) : View(ctx) {
    var recording: Boolean = false
        set(v) { field = v; invalidate() }
    private val d = resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 4f * d
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE53935.toInt() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - ring.strokeWidth
        c.drawCircle(cx, cy, r, ring)
        if (recording) {
            val s = r * 0.5f
            c.drawRoundRect(cx - s, cy - s, cx + s, cy + s, 6f * d, 6f * d, fill)
        } else {
            c.drawCircle(cx, cy, r * 0.78f, fill)
        }
    }
}

/** Subtle rounded rectangle showing where the tracked face is inside the preview. */
class FaceOverlay(ctx: Context) : View(ctx) {
    private var rect: RectF? = null
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xAA00E5A0.toInt(); strokeWidth = 2f * d
    }

    fun show(normalized: RectF?) { rect = normalized; invalidate() }

    override fun onDraw(c: Canvas) {
        val r = rect ?: return
        c.drawRoundRect(r.left * width, r.top * height, r.right * width, r.bottom * height, 12f * d, 12f * d, paint)
    }
}
