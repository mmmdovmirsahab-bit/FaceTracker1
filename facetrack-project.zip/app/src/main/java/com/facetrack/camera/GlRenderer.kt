package com.facetrack.camera

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import androidx.camera.core.SurfaceRequest
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executor
import java.util.concurrent.TimeUnit

/**
 * Owns the camera texture. Every camera frame is drawn with the current face-following crop
 * (1) to the on-screen preview (mirrored, selfie style) and (2) when recording, to the
 * MediaCodec input surface (NOT mirrored). So the encoded video really is the reframed video.
 */
class GlRenderer(private val tracker: FaceTracker) {

    private companion object {
        const val TAG = "FaceTrackGL"
        const val EGL_RECORDABLE_ANDROID = 0x3142
        /** Preview is mirrored like a selfie; recorded file is not mirrored (like most camera apps). */
        const val MIRROR_RECORDING = false
        const val VERTEX = """
            attribute vec4 aPos;
            uniform mat3 uM;
            uniform mat4 uTex;
            varying vec2 vTex;
            void main() {
                gl_Position = aPos;
                vec2 st = vec2((aPos.x + 1.0) * 0.5, (1.0 - aPos.y) * 0.5);
                vec2 tc = (uM * vec3(st, 1.0)).xy;
                vTex = (uTex * vec4(tc, 0.0, 1.0)).xy;
            }"""
        const val FRAGMENT = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vTex;
            uniform samplerExternalOES sTex;
            void main() { gl_FragColor = texture2D(sTex, vTex); }"""
    }

    private val thread = HandlerThread("FaceTrack-GL").also { it.start() }
    private val handler = Handler(thread.looper)
    private val glExecutor = Executor { handler.post(it) }

    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var config: EGLConfig? = null
    private var pbuffer: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var locPos = 0
    private var locM = 0
    private var locTex = 0
    private var locSampler = 0
    private var texId = 0
    private var st: SurfaceTexture? = null
    private val texMat = FloatArray(16)
    private val quad = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0)
    }

    private var previewEgl: EGLSurface? = null
    private var encEgl: EGLSurface? = null
    private var encStartNs = 0L

    @Volatile private var released = false
    @Volatile private var rotation = 0
    @Volatile private var bufW = 0
    @Volatile private var bufH = 0
    @Volatile var hasFrames = false
        private set

    init { handler.post { initGl() } }

    // ---------------------------------------------------------------- setup
    private fun initGl() {
        try {
            display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val v = IntArray(2)
            EGL14.eglInitialize(display, v, 0, v, 1)
            val attribs = intArrayOf(
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL_RECORDABLE_ANDROID, 1, EGL14.EGL_NONE
            )
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val n = IntArray(1)
            EGL14.eglChooseConfig(display, attribs, 0, cfgs, 0, 1, n, 0)
            config = cfgs[0] ?: throw IllegalStateException("No EGL config")
            eglContext = EGL14.eglCreateContext(
                display, config, EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
            )
            pbuffer = EGL14.eglCreatePbufferSurface(
                display, config, intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
            )
            makeCurrent(pbuffer)

            program = buildProgram()
            locPos = GLES20.glGetAttribLocation(program, "aPos")
            locM = GLES20.glGetUniformLocation(program, "uM")
            locTex = GLES20.glGetUniformLocation(program, "uTex")
            locSampler = GLES20.glGetUniformLocation(program, "sTex")

            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            texId = t[0]
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            val s = SurfaceTexture(texId)
            s.setOnFrameAvailableListener({ onFrame() }, handler)
            st = s
        } catch (e: Exception) {
            Log.e(TAG, "GL init failed", e)
        }
    }

    private fun buildProgram(): Int {
        fun compile(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw IllegalStateException("Shader error: " + GLES20.glGetShaderInfoLog(s))
            return s
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, VERTEX))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw IllegalStateException("Link error: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    private fun makeCurrent(s: EGLSurface) {
        EGL14.eglMakeCurrent(display, s, s, eglContext)
    }

    // ---------------------------------------------------------------- CameraX hookup
    fun onSurfaceRequest(request: SurfaceRequest) {
        handler.post {
            val tex = st
            if (released || tex == null) {
                request.willNotProvideSurface()
                return@post
            }
            val size = request.resolution
            bufW = size.width
            bufH = size.height
            tex.setDefaultBufferSize(size.width, size.height)
            val surface = Surface(tex)
            request.setTransformationInfoListener(glExecutor) { info -> rotation = info.rotationDegrees }
            request.provideSurface(surface, glExecutor) { surface.release() }
        }
    }

    // ---------------------------------------------------------------- preview surface
    fun setPreviewSurface(s: Surface?, w: Int, h: Int) {
        val work: () -> Unit = {
            previewEgl?.let {
                makeCurrent(pbuffer)
                EGL14.eglDestroySurface(display, it)
            }
            previewEgl = null
            if (s != null && s.isValid && display != EGL14.EGL_NO_DISPLAY) {
                val e = EGL14.eglCreateWindowSurface(display, config, s, intArrayOf(EGL14.EGL_NONE), 0)
                if (e != EGL14.EGL_NO_SURFACE) previewEgl = e
            }
        }
        if (s == null) runSync(800, work) else handler.post { work() }
    }

    // ---------------------------------------------------------------- encoder surface
    fun startEncoding(surface: Surface, startNs: Long) {
        runSync(2000) {
            val e = EGL14.eglCreateWindowSurface(display, config, surface, intArrayOf(EGL14.EGL_NONE), 0)
            if (e == EGL14.EGL_NO_SURFACE) throw IllegalStateException("Cannot create encoder EGL surface")
            encStartNs = startNs
            encEgl = e
        }
    }

    private var encW = 0
    private var encH = 0
    fun setEncodeSize(w: Int, h: Int) { encW = w; encH = h }

    fun stopEncoding() {
        runSync(2000) {
            encEgl?.let {
                makeCurrent(pbuffer)
                EGL14.eglDestroySurface(display, it)
            }
            encEgl = null
        }
    }

    private fun runSync(timeoutMs: Long, block: () -> Unit) {
        if (Looper.myLooper() == handler.looper) { block(); return }
        val latch = CountDownLatch(1)
        var err: Throwable? = null
        handler.post {
            try { block() } catch (t: Throwable) { err = t } finally { latch.countDown() }
        }
        latch.await(timeoutMs, TimeUnit.MILLISECONDS)
        err?.let { throw it }
    }

    // ---------------------------------------------------------------- per-frame work
    private fun onFrame() {
        if (released) return
        val tex = st ?: return
        try {
            makeCurrent(pbuffer)
            tex.updateTexImage()
            tex.getTransformMatrix(texMat)
            if (bufW == 0 || bufH == 0) return
            val rot = rotation
            val fa = if (rot % 180 == 0) bufW.toFloat() / bufH else bufH.toFloat() / bufW
            tracker.frameAspect = fa
            val nowNs = SystemClock.elapsedRealtimeNanos()
            val crop = tracker.nextCrop(nowNs)

            previewEgl?.let { surf ->
                makeCurrent(surf)
                val w = IntArray(1); val h = IntArray(1)
                EGL14.eglQuerySurface(display, surf, EGL14.EGL_WIDTH, w, 0)
                EGL14.eglQuerySurface(display, surf, EGL14.EGL_HEIGHT, h, 0)
                GLES20.glViewport(0, 0, w[0], h[0])
                draw(crop, rot, true)
                EGL14.eglSwapBuffers(display, surf)
            }
            encEgl?.let { surf ->
                val pts = nowNs - encStartNs
                if (pts >= 0) {
                    makeCurrent(surf)
                    GLES20.glViewport(0, 0, encW, encH)
                    draw(crop, rot, MIRROR_RECORDING)
                    EGLExt.eglPresentationTimeANDROID(display, surf, pts)
                    EGL14.eglSwapBuffers(display, surf)
                }
            }
            hasFrames = true
        } catch (e: Exception) {
            Log.e(TAG, "frame error", e)
        }
    }

    private fun draw(crop: Crop, rot: Int, mirror: Boolean) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glUniform1i(locSampler, 0)
        GLES20.glUniformMatrix3fv(locM, 1, false, affine(crop, rot, mirror), 0)
        GLES20.glUniformMatrix4fv(locTex, 1, false, texMat, 0)
        GLES20.glEnableVertexAttribArray(locPos)
        GLES20.glVertexAttribPointer(locPos, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(locPos)
    }

    /**
     * Output pixel (s,t) [0..1, origin top-left] -> crop in upright space -> rotate back to the
     * raw sensor buffer -> GL texcoord (v up). Returned as column-major mat3 for the shader.
     */
    private fun affine(c: Crop, rot: Int, mirror: Boolean): FloatArray {
        val p0 = map(c, rot, mirror, 0f, 0f)
        val p1 = map(c, rot, mirror, 1f, 0f)
        val p2 = map(c, rot, mirror, 0f, 1f)
        return floatArrayOf(
            p1[0] - p0[0], p1[1] - p0[1], 0f,
            p2[0] - p0[0], p2[1] - p0[1], 0f,
            p0[0], p0[1], 1f
        )
    }

    private fun map(c: Crop, rot: Int, mirror: Boolean, s: Float, t: Float): FloatArray {
        val ss = if (mirror) 1f - s else s
        val xu = c.x0 + ss * c.w
        val yu = c.y0 + t * c.h
        var p = xu
        var q = yu
        when (rot) {
            90 -> { p = yu; q = 1f - xu }
            180 -> { p = 1f - xu; q = 1f - yu }
            270 -> { p = 1f - yu; q = xu }
        }
        return floatArrayOf(p, 1f - q)
    }

    // ---------------------------------------------------------------- teardown
    fun release() {
        released = true
        handler.post {
            try {
                previewEgl?.let { makeCurrent(pbuffer); EGL14.eglDestroySurface(display, it) }
                encEgl?.let { makeCurrent(pbuffer); EGL14.eglDestroySurface(display, it) }
                previewEgl = null; encEgl = null
                st?.release(); st = null
                if (program != 0) GLES20.glDeleteProgram(program)
                if (display != EGL14.EGL_NO_DISPLAY) {
                    EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                    if (pbuffer != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, pbuffer)
                    if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, eglContext)
                    EGL14.eglTerminate(display)
                }
            } catch (e: Exception) {
                Log.e(TAG, "release error", e)
            }
        }
        thread.quitSafely()
    }
}
