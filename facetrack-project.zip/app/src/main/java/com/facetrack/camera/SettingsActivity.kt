package com.facetrack.camera

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import androidx.activity.ComponentActivity

class SettingsActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val prefs = Prefs(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(32))
        }
        col.addView(TextView(this).apply {
            text = "←  Settings"; textSize = 24f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); setPadding(0, 0, 0, dp(16))
            setOnClickListener { finish() }
        })
        col.addView(switchRow("Face tracking", prefs.trackingEnabled) { prefs.trackingEnabled = it })
        col.addView(slider("Tracking sensitivity", "How quickly the frame follows you", prefs.sensitivity) { prefs.sensitivity = it })
        col.addView(slider("Crop / framing strength", "Maximum zoom-in on your face", prefs.strength) { prefs.strength = it })
        col.addView(slider("Face framing margin", "Space around your face", prefs.margin) { prefs.margin = it })
        col.addView(slider("Smoothing", "Higher = calmer, slower camera movement", prefs.smoothing) { prefs.smoothing = it })

        col.addView(label("Video resolution (supported on this phone)"))
        val sizes = Caps.supportedOutputs(this)
        val spinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sizes.map { it.label })
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.setSelection(sizes.indexOfFirst { it.h == prefs.outputHeight }.coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { prefs.outputHeight = sizes[pos].h }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        col.addView(spinner)
        col.addView(switchRow("Record microphone audio", prefs.recordAudio) { prefs.recordAudio = it })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF101418.toInt())
            addView(col)
        })
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 16f; setPadding(0, dp(18), 0, dp(4))
    }

    private fun switchRow(title: String, value: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = title; textSize = 16f; setTextColor(Color.WHITE); isChecked = value
        setPadding(0, dp(14), 0, dp(14))
        setOnCheckedChangeListener { _, c -> onChange(c) }
    }

    private fun slider(title: String, desc: String, value: Int, onChange: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = label("$title: $value%")
        val sub = TextView(this).apply { text = desc; setTextColor(Color.GRAY); textSize = 13f }
        val bar = SeekBar(this).apply {
            max = 100; progress = value
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    head.text = "$title: $p%"
                    if (fromUser) onChange(p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(head); box.addView(sub); box.addView(bar)
        return box
    }
}
