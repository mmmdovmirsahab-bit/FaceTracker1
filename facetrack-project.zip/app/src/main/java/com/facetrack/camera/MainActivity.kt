package com.facetrack.camera

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Size
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity(), SurfaceHolder.Callback {

    private lateinit var prefs: Prefs
    private val tracker = FaceTracker()
    private lateinit var renderer: GlRenderer
    private lateinit var recorder: Recorder

    private lateinit var previewHost: FrameLayout
    private lateinit var surfaceView: SurfaceView
    private lateinit var overlay: FaceOverlay
    private lateinit var statusText: TextView
    private lateinit var timerText: TextView
    private lateinit var trackBtn: TextView
    private lateinit var errorText: TextView
    private lateinit var permPanel: LinearLayout
    private lateinit var permMsg: TextView
    private lateinit var recordBtn: RecordButton

    private var provider: ProcessCameraProvider? = null
    private var analysisExecutor: ExecutorService? = null
    private var analyzer: FaceAnalyzer? = null
    private var analysisUseCase: ImageAnalysis? = null

    private var recording = false
    private var finalizing = false
    private var recordStartMs = 0L
    private var askedPermissions = false

    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { updateUi(); ui.postDelayed(this, 50) }
    }
    private val clearError = Runnable { errorText.visibility = View.GONE }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (has(Manifest.permission.CAMERA)) { permPanel.visibility = View.GONE; startCamera() } else showPermPanel()
    }

    // ------------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        prefs = Prefs(this)
        renderer = GlRenderer(tracker)
        recorder = Recorder(this, renderer)
        recorder.onError = { msg -> runOnUiThread { showError(msg); if (recording) stopRecording() } }
        setContentView(buildUi())
    }

    override fun onStart() {
        super.onStart()
        tracker.settings = prefs.trackSettings()
        refreshTrackButton()
        ui.post(tick)
        if (has(Manifest.permission.CAMERA)) {
            permPanel.visibility = View.GONE
            startCamera()
        } else if (!askedPermissions) {
            askedPermissions = true
            permLauncher.launch(requiredPermissions())
        } else showPermPanel()
    }

    override fun onStop() {
        super.onStop()
        ui.removeCallbacks(tick)
        if (recording) stopRecording()
        releaseCamera()
    }

    override fun onDestroy() {
        super.onDestroy()
        renderer.release()
    }

    // ------------------------------------------------------------------ permissions
    private fun requiredPermissions(): Array<String> = buildList {
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT < 29) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }.toTypedArray()

    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun showPermPanel() {
        permMsg.text = "FaceTrack needs the camera permission to show the preview and record video. " +
            "Microphone permission is optional (for sound)."
        permPanel.visibility = View.VISIBLE
    }

    // ------------------------------------------------------------------ camera
    private fun selector(w: Int, h: Int) = ResolutionSelector.Builder()
        .setAspectRatioStrategy(AspectRatioStrategy(AspectRatio.RATIO_16_9, AspectRatioStrategy.FALLBACK_RULE_AUTO))
        .setResolutionStrategy(ResolutionStrategy(Size(w, h), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER))
        .build()

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                provider = future.get()
                bindCamera()
            } catch (e: Exception) {
                showError("Camera failed to start: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCamera() {
        val p = provider ?: return
        if (!p.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)) {
            showError("This device has no front camera")
            return
        }
        releaseAnalysis()
        p.unbindAll()
        val preview = Preview.Builder()
            .setResolutionSelector(selector(1920, 1080))
            .setTargetRotation(android.view.Surface.ROTATION_0)
            .build()
        preview.setSurfaceProvider(ContextCompat.getMainExecutor(this)) { request ->
            renderer.onSurfaceRequest(request)
        }
        val exec = Executors.newSingleThreadExecutor()
        val an = FaceAnalyzer(tracker, exec)
        val analysis = ImageAnalysis.Builder()
            .setResolutionSelector(selector(960, 540))
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setTargetRotation(android.view.Surface.ROTATION_0)
            .build()
        analysis.setAnalyzer(exec, an)
        analysisExecutor = exec; analyzer = an; analysisUseCase = analysis
        try {
            p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
        } catch (e: Exception) {
            showError("Could not open the camera: ${e.message}")
        }
    }

    private fun releaseAnalysis() {
        try { analysisUseCase?.clearAnalyzer() } catch (e: Exception) { /* ignore */ }
        analyzer?.close()
        analysisExecutor?.shutdown()
        analyzer = null; analysisExecutor = null; analysisUseCase = null
    }

    private fun releaseCamera() {
        try { provider?.unbindAll() } catch (e: Exception) { /* ignore */ }
        releaseAnalysis()
    }

    // ------------------------------------------------------------------ recording
    private fun toggleRecord() {
        if (finalizing) return
        if (recording) stopRecording() else startRecording()
    }

    private fun startRecording() {
        if (Build.VERSION.SDK_INT < 29 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            permLauncher.launch(requiredPermissions())
            showError("Storage permission is needed to save videos on this Android version")
            return
        }
        if (!renderer.hasFrames) { showError("Camera is not ready yet"); return }
        val audio = prefs.recordAudio && has(Manifest.permission.RECORD_AUDIO)
        try {
            val warning = recorder.start(prefs.outputHeight, audio)
            recording = true
            recordStartMs = SystemClock.elapsedRealtime()
            recordBtn.recording = true
            recordBtn.contentDescription = "Stop recording"
            if (warning != null) showError(warning)
            else if (prefs.recordAudio && !audio) showError("No microphone permission - recording without audio")
        } catch (e: Exception) {
            showError("Cannot start recording: ${e.message}")
        }
    }

    private fun stopRecording() {
        if (!recording) return
        recording = false
        finalizing = true
        recordBtn.recording = false
        recordBtn.contentDescription = "Start recording"
        Thread {
            val r = recorder.stop()
            runOnUiThread {
                finalizing = false
                if (r.uri != null) {
                    prefs.lastUri = r.uri.toString()
                    Toast.makeText(this, "Saved to Movies/FaceTrack", Toast.LENGTH_LONG).show()
                } else showError(r.error ?: "Recording failed")
            }
        }.start()
    }

    private fun openGallery() {
        val u = prefs.lastUri
        val intent = if (u != null) {
            Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), "video/mp4")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else Intent(Intent.ACTION_VIEW, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
        try { startActivity(intent) } catch (e: Exception) {
            Toast.makeText(this, "No gallery app found", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------ UI
    private fun showError(msg: String) {
        errorText.text = msg
        errorText.visibility = View.VISIBLE
        ui.removeCallbacks(clearError)
        ui.postDelayed(clearError, 7000)
    }

    private fun refreshTrackButton() {
        trackBtn.text = if (prefs.trackingEnabled) "TRACKING ON" else "TRACKING OFF"
        trackBtn.setTextColor(if (prefs.trackingEnabled) 0xFF00E5A0.toInt() else Color.LTGRAY)
    }

    private fun updateUi() {
        val now = SystemClock.elapsedRealtime()
        val snap = tracker.snapshot(now)
        when (snap.state) {
            TrackState.FOUND -> { statusText.text = "● Face detected"; statusText.setTextColor(0xFF00E5A0.toInt()) }
            TrackState.SEARCHING -> { statusText.text = "● Searching for face"; statusText.setTextColor(0xFFFFC107.toInt()) }
            TrackState.PAUSED -> { statusText.text = "● Tracking paused"; statusText.setTextColor(Color.LTGRAY) }
        }
        if (recording) {
            val s = (now - recordStartMs) / 1000
            timerText.text = "● REC  %02d:%02d".format(s / 60, s % 60)
            timerText.visibility = View.VISIBLE
        } else timerText.visibility = View.INVISIBLE

        val f = snap.face
        if (f == null) overlay.show(null) else {
            val c = snap.crop
            val cx = 1f - (f.cx - c.x0) / c.w          // preview is mirrored
            val cy = (f.cy - c.y0) / c.h
            val hw = f.w / c.w / 2f
            val hh = f.h / c.h / 2f
            overlay.show(RectF(cx - hw, cy - hh, cx + hw, cy + hh))
        }
    }

    private fun chip(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 13f
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(0x99000000.toInt()) }
    }

    private fun fit(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val tw: Int
        val th: Int
        if (w.toFloat() / h > OUT_ASPECT) { th = h; tw = (h * OUT_ASPECT).toInt() } else { tw = w; th = (w / OUT_ASPECT).toInt() }
        val lp = FrameLayout.LayoutParams(tw, th, Gravity.CENTER)
        surfaceView.layoutParams = lp
        overlay.layoutParams = FrameLayout.LayoutParams(tw, th, Gravity.CENTER)
    }

    private fun buildUi(): View {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        previewHost = FrameLayout(this)
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        overlay = FaceOverlay(this)
        previewHost.addView(surfaceView, FrameLayout.LayoutParams(1, 1, Gravity.CENTER))
        previewHost.addView(overlay, FrameLayout.LayoutParams(1, 1, Gravity.CENTER))
        previewHost.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> fit(r - l, b - t) }
        root.addView(previewHost, FrameLayout.LayoutParams(match, match))

        // top area
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(12), dp(16), 0)
        }
        val topRow = FrameLayout(this)
        topRow.addView(chip("● FRONT CAMERA"), FrameLayout.LayoutParams(wrap, wrap, Gravity.START))
        trackBtn = chip("TRACKING ON")
        trackBtn.contentDescription = "Toggle face tracking"
        trackBtn.setOnClickListener {
            prefs.trackingEnabled = !prefs.trackingEnabled
            tracker.settings = prefs.trackSettings()
            refreshTrackButton()
        }
        topRow.addView(trackBtn, FrameLayout.LayoutParams(wrap, wrap, Gravity.END))
        top.addView(topRow, LinearLayout.LayoutParams(match, wrap))
        statusText = chip("● Searching for face")
        top.addView(statusText, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(12) })
        timerText = TextView(this).apply {
            setTextColor(0xFFFF5252.toInt()); textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            visibility = View.INVISIBLE; setPadding(0, dp(10), 0, 0)
        }
        top.addView(timerText, LinearLayout.LayoutParams(wrap, wrap))
        root.addView(top, FrameLayout.LayoutParams(match, wrap, Gravity.TOP))

        // error banner
        errorText = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; visibility = View.GONE
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(0xDDB71C1C.toInt()) }
            setOnClickListener { visibility = View.GONE }
        }
        root.addView(errorText, FrameLayout.LayoutParams(match, wrap, Gravity.BOTTOM).apply {
            setMargins(dp(16), 0, dp(16), dp(150))
        })

        // bottom controls
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(16), dp(16))
        }
        val gallery = chip("▶  Gallery").apply {
            contentDescription = "Open last recording"; setOnClickListener { openGallery() }
        }
        val settingsBtn = chip("⚙  Settings").apply {
            contentDescription = "Open settings"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        recordBtn = RecordButton(this).apply {
            contentDescription = "Start recording"; setOnClickListener { toggleRecord() }
        }
        fun slot(v: View, g: Int): FrameLayout = FrameLayout(this).apply {
            addView(v, FrameLayout.LayoutParams(wrap, wrap, g))
        }
        bottom.addView(slot(gallery, Gravity.START or Gravity.CENTER_VERTICAL), LinearLayout.LayoutParams(0, wrap, 1f))
        bottom.addView(recordBtn, LinearLayout.LayoutParams(dp(84), dp(84)))
        bottom.addView(slot(settingsBtn, Gravity.END or Gravity.CENTER_VERTICAL), LinearLayout.LayoutParams(0, wrap, 1f))
        root.addView(bottom, FrameLayout.LayoutParams(match, dp(120), Gravity.BOTTOM))

        // permission panel
        permPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xF2101418.toInt())
            setPadding(dp(28), dp(28), dp(28), dp(28))
            visibility = View.GONE
            isClickable = true
        }
        permMsg = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER }
        permPanel.addView(permMsg)
        permPanel.addView(Button(this).apply {
            text = "Grant permission"
            setOnClickListener { permLauncher.launch(requiredPermissions()) }
        })
        permPanel.addView(Button(this).apply {
            text = "Open app settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        })
        root.addView(permPanel, FrameLayout.LayoutParams(match, match))
        return root
    }

    // ------------------------------------------------------------------ SurfaceHolder.Callback
    override fun surfaceCreated(holder: SurfaceHolder) {}

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        renderer.setPreviewSurface(holder.surface, width, height)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        renderer.setPreviewSurface(null, 0, 0)
    }
}
