package com.facetrack.camera

import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.MediaCodecList
import kotlin.math.max

data class OutSize(val w: Int, val h: Int, val label: String)

object Caps {
    private val ALL = listOf(
        OutSize(1080, 1920, "1080p (1080×1920)"),
        OutSize(720, 1280, "720p (720×1280)"),
        OutSize(480, 848, "480p (480×848)")
    )

    /** Output sizes the front camera and the H.264 encoder can actually deliver on this phone. */
    fun supportedOutputs(ctx: Context): List<OutSize> {
        val maxLong = frontMaxLongSide(ctx)
        val list = ALL.filter { (maxLong == 0 || maxLong >= it.h) && encoderSupports(it.w, it.h) }
        return list.ifEmpty { listOf(ALL.last()) }
    }

    private fun frontMaxLongSide(ctx: Context): Int = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        var best = 0
        for (id in cm.cameraIdList) {
            val c = cm.getCameraCharacteristics(id)
            if (c.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_FRONT) continue
            val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: continue
            for (s in map.getOutputSizes(SurfaceTexture::class.java) ?: emptyArray()) {
                best = max(best, max(s.width, s.height))
            }
        }
        best
    } catch (e: Exception) { 0 }

    private fun encoderSupports(w: Int, h: Int): Boolean = try {
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { info ->
            info.isEncoder && info.supportedTypes.any { it.equals("video/avc", true) } &&
                info.getCapabilitiesForType("video/avc").videoCapabilities.let {
                    it.isSizeSupported(w, h) || it.isSizeSupported(h, w)
                }
        }
    } catch (e: Exception) { true }
}
