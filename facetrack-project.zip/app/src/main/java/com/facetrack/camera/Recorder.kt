package com.facetrack.camera

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Writes encoded samples; buffers early samples until every expected track has been added. */
class MuxerHub(private val muxer: MediaMuxer, private val expected: Int) {
    private class Pending(val track: Int, val data: ByteArray, val info: MediaCodec.BufferInfo)

    private val pending = ArrayList<Pending>()
    private var added = 0
    private var started = false
    private var wrote = false

    @Synchronized
    fun addTrack(format: MediaFormat): Int {
        val t = muxer.addTrack(format)
        added++
        if (added == expected) {
            muxer.start()
            started = true
            for (p in pending) {
                muxer.writeSampleData(p.track, ByteBuffer.wrap(p.data), p.info)
                wrote = true
            }
            pending.clear()
        }
        return t
    }

    @Synchronized
    fun write(track: Int, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        buf.position(info.offset)
        buf.limit(info.offset + info.size)
        if (started) {
            muxer.writeSampleData(track, buf, info)
            wrote = true
        } else {
            val arr = ByteArray(info.size)
            buf.get(arr)
            val i = MediaCodec.BufferInfo()
            i.set(0, info.size, info.presentationTimeUs, info.flags)
            pending.add(Pending(track, arr, i))
        }
    }

    /** Returns an error message or null on success. */
    @Synchronized
    fun finish(): String? {
        var err: String? = null
        try {
            if (started) muxer.stop() else err = "Recording produced no data"
        } catch (e: Exception) {
            err = "Could not finalize file: ${e.message}"
        }
        try { muxer.release() } catch (e: Exception) { /* ignore */ }
        if (err == null && !wrote) err = "No frames were recorded"
        return err
    }
}

internal fun drainCodec(
    codec: MediaCodec, info: MediaCodec.BufferInfo, timeoutUs: Long, hub: MuxerHub, track: IntArray
): Boolean {
    while (true) {
        val idx = codec.dequeueOutputBuffer(info, timeoutUs)
        when {
            idx == MediaCodec.INFO_TRY_AGAIN_LATER -> return false
            idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> track[0] = hub.addTrack(codec.outputFormat)
            idx >= 0 -> {
                val buf = codec.getOutputBuffer(idx)
                if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                if (buf != null && info.size > 0 && track[0] >= 0) hub.write(track[0], buf, info)
                codec.releaseOutputBuffer(idx, false)
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return true
            }
        }
    }
}

class VideoEncoder(
    val width: Int, val height: Int, bitrate: Int, fps: Int,
    private val hub: MuxerHub, private val onError: (String) -> Unit
) {
    private val codec: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
    lateinit var inputSurface: Surface
        private set
    private val track = intArrayOf(-1)
    @Volatile private var aborted = false
    private var thread: Thread? = null

    init {
        try {
            val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height)
            f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = codec.createInputSurface()
            codec.start()
        } catch (e: Exception) {
            codec.release()
            throw e
        }
    }

    fun startDraining() {
        thread = Thread({
            try {
                val info = MediaCodec.BufferInfo()
                while (!aborted) {
                    if (drainCodec(codec, info, 10_000, hub, track)) break
                }
            } catch (e: Exception) {
                onError("Video encoder error: ${e.message}")
            }
        }, "FT-VideoDrain").also { it.start() }
    }

    fun stop() {
        try { codec.signalEndOfInputStream() } catch (e: Exception) { /* ignore */ }
        thread?.join(4000)
        aborted = true
        try { codec.stop() } catch (e: Exception) { /* ignore */ }
        codec.release()
        inputSurface.release()
    }

    fun abort() {
        aborted = true
        try { codec.stop() } catch (e: Exception) { /* ignore */ }
        try { codec.release() } catch (e: Exception) { /* ignore */ }
        try { inputSurface.release() } catch (e: Exception) { /* ignore */ }
    }
}

class AudioEncoder private constructor(private val record: AudioRecord) {
    companion object {
        const val RATE = 44100

        @SuppressLint("MissingPermission")
        fun create(): AudioEncoder? {
            val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) return null
            return try {
                val r = AudioRecord(
                    MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, max(min * 2, 16384)
                )
                if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); null } else AudioEncoder(r)
            } catch (e: Exception) { null }
        }
    }

    private val codec: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
    private val track = intArrayOf(-1)
    @Volatile private var stopFlag = false
    private var thread: Thread? = null

    fun start(hub: MuxerHub, startNs: Long, onError: (String) -> Unit) {
        val f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, RATE, 1)
        f.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        f.setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
        f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
        thread = Thread({
            try { loop(hub, startNs) } catch (e: Exception) { onError("Audio error: ${e.message}") }
        }, "FT-Audio").also { it.start() }
    }

    private fun loop(hub: MuxerHub, startNs: Long) {
        val info = MediaCodec.BufferInfo()
        var samples = 0L
        var baseNs = -1L
        var lastPts = 0L
        record.startRecording()
        while (!stopFlag) {
            val idx = codec.dequeueInputBuffer(10_000)
            if (idx >= 0) {
                val buf = codec.getInputBuffer(idx)!!
                buf.clear()
                val n = record.read(buf, min(buf.capacity(), 4096))
                if (n < 0) throw IllegalStateException("AudioRecord read error $n")
                if (n > 0 && baseNs < 0) {
                    baseNs = max(0L, SystemClock.elapsedRealtimeNanos() - startNs - (n / 2) * 1_000_000_000L / RATE)
                }
                val pts = (max(baseNs, 0L) + samples * 1_000_000_000L / RATE) / 1000L
                samples += n / 2
                lastPts = pts
                codec.queueInputBuffer(idx, 0, max(n, 0), pts, 0)
            }
            drainCodec(codec, info, 0, hub, track)
        }
        // end of stream
        var queued = false
        for (i in 0 until 50) {
            val idx = codec.dequeueInputBuffer(20_000)
            if (idx >= 0) {
                codec.queueInputBuffer(idx, 0, 0, lastPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                queued = true
                break
            }
        }
        if (queued) {
            for (i in 0 until 200) {
                if (drainCodec(codec, info, 10_000, hub, track)) break
            }
        }
    }

    fun stop() {
        stopFlag = true
        thread?.join(4000)
        try { record.stop() } catch (e: Exception) { /* ignore */ }
        record.release()
        try { codec.stop() } catch (e: Exception) { /* ignore */ }
        codec.release()
    }

    fun abort() {
        stopFlag = true
        try { record.release() } catch (e: Exception) { /* ignore */ }
        try { codec.release() } catch (e: Exception) { /* ignore */ }
    }
}

class Recorder(private val ctx: Context, private val renderer: GlRenderer) {
    class Result(val uri: Uri?, val error: String?)

    var onError: ((String) -> Unit)? = null
    @Volatile var active = false
        private set

    private var uri: Uri? = null
    private var pfd: ParcelFileDescriptor? = null
    private var hub: MuxerHub? = null
    private var video: VideoEncoder? = null
    private var audio: AudioEncoder? = null

    /** Starts recording. Returns a warning message (e.g. "no audio") or null. Throws on failure. */
    fun start(preferredHeight: Int, wantAudio: Boolean): String? {
        check(!active) { "Already recording" }
        val sizes = Caps.supportedOutputs(ctx)
        val candidates = sizes.filter { it.h <= preferredHeight }.ifEmpty { sizes.takeLast(1) }
        val (u, p) = createOutput()
        uri = u; pfd = p
        var warning: String? = null
        try {
            var aud: AudioEncoder? = null
            if (wantAudio) {
                aud = AudioEncoder.create()
                if (aud == null) warning = "Microphone unavailable - recording without audio"
            }
            val muxer = MediaMuxer(p.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val h = MuxerHub(muxer, if (aud != null) 2 else 1)
            var venc: VideoEncoder? = null
            var lastErr: Exception? = null
            for (s in candidates) {
                try {
                    val bitrate = (s.w.toLong() * s.h * 30 * 0.15).toInt()
                    venc = VideoEncoder(s.w, s.h, bitrate, 30, h) { msg -> onError?.invoke(msg) }
                    break
                } catch (e: Exception) { lastErr = e }
            }
            if (venc == null) throw lastErr ?: IllegalStateException("No video encoder available")
            hub = h; video = venc; audio = aud
            val startNs = SystemClock.elapsedRealtimeNanos()
            renderer.setEncodeSize(venc.width, venc.height)
            renderer.startEncoding(venc.inputSurface, startNs)
            venc.startDraining()
            aud?.start(h, startNs) { msg -> onError?.invoke(msg) }
            active = true
        } catch (e: Exception) {
            cleanupFailedStart()
            throw e
        }
        return warning
    }

    private fun cleanupFailedStart() {
        try { renderer.stopEncoding() } catch (e: Exception) { /* ignore */ }
        video?.abort(); audio?.abort()
        try { hub?.finish() } catch (e: Exception) { /* ignore */ }
        try { pfd?.close() } catch (e: Exception) { /* ignore */ }
        uri?.let { try { ctx.contentResolver.delete(it, null, null) } catch (e: Exception) { /* ignore */ } }
        video = null; audio = null; hub = null; uri = null; pfd = null
    }

    fun stop(): Result {
        if (!active) return Result(null, "Not recording")
        active = false
        try { renderer.stopEncoding() } catch (e: Exception) { /* ignore */ }
        try { audio?.stop() } catch (e: Exception) { /* ignore */ }
        try { video?.stop() } catch (e: Exception) { /* ignore */ }
        val err = hub?.finish()
        try { pfd?.close() } catch (e: Exception) { /* ignore */ }
        val u = uri
        video = null; audio = null; hub = null; uri = null; pfd = null
        if (u == null) return Result(null, err ?: "No output file")
        if (err != null) {
            try { ctx.contentResolver.delete(u, null, null) } catch (e: Exception) { /* ignore */ }
            return Result(null, err)
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            try { ctx.contentResolver.update(u, v, null, null) } catch (e: Exception) { /* ignore */ }
        }
        return Result(u, null)
    }

    private fun createOutput(): Pair<Uri, ParcelFileDescriptor> {
        val name = "FaceTrack_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FaceTrack")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "FaceTrack")
                dir.mkdirs()
                put(MediaStore.MediaColumns.DATA, File(dir, name).absolutePath)
            }
        }
        val u = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
            ?: error("Could not create the video file")
        val p = ctx.contentResolver.openFileDescriptor(u, "rw") ?: error("Could not open the video file")
        return u to p
    }
}
