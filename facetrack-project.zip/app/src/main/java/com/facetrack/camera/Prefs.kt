package com.facetrack.camera

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("facetrack", Context.MODE_PRIVATE)

    var trackingEnabled: Boolean
        get() = sp.getBoolean("tracking", true)
        set(v) = sp.edit().putBoolean("tracking", v).apply()
    var sensitivity: Int
        get() = sp.getInt("sensitivity", 60)
        set(v) = sp.edit().putInt("sensitivity", v).apply()
    var smoothing: Int
        get() = sp.getInt("smoothing", 50)
        set(v) = sp.edit().putInt("smoothing", v).apply()
    var strength: Int
        get() = sp.getInt("strength", 50)
        set(v) = sp.edit().putInt("strength", v).apply()
    var margin: Int
        get() = sp.getInt("margin", 50)
        set(v) = sp.edit().putInt("margin", v).apply()
    var recordAudio: Boolean
        get() = sp.getBoolean("audio", true)
        set(v) = sp.edit().putBoolean("audio", v).apply()
    var outputHeight: Int
        get() = sp.getInt("outH", 1280)
        set(v) = sp.edit().putInt("outH", v).apply()
    var lastUri: String?
        get() = sp.getString("lastUri", null)
        set(v) = sp.edit().putString("lastUri", v).apply()

    fun trackSettings() = TrackSettings(
        enabled = trackingEnabled,
        sensitivity = sensitivity / 100f,
        smoothing = smoothing / 100f,
        strength = strength / 100f,
        margin = margin / 100f
    )
}
