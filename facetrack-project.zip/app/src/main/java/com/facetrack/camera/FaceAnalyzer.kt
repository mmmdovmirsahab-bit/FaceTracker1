package com.facetrack.camera

import android.os.SystemClock
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executor

/** On-device ML Kit face detection. Frames never leave the phone. */
class FaceAnalyzer(
    private val tracker: FaceTracker,
    private val callbackExecutor: Executor
) : ImageAnalysis.Analyzer {

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_NONE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .setMinFaceSize(0.1f)
            .enableTracking()
            .build()
    )

    @Volatile private var closed = false

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(image: ImageProxy) {
        val media = image.image
        if (media == null || closed || !tracker.settings.enabled) {
            image.close()
            return
        }
        try {
            val rot = image.imageInfo.rotationDegrees
            val iw = (if (rot % 180 == 0) image.width else image.height).toFloat()
            val ih = (if (rot % 180 == 0) image.height else image.width).toFloat()
            val input = InputImage.fromMediaImage(media, rot)
            detector.process(input)
                .addOnSuccessListener(callbackExecutor) { faces ->
                    val boxes = faces.map {
                        val b = it.boundingBox
                        FaceBox(it.trackingId, b.exactCenterX() / iw, b.exactCenterY() / ih,
                            b.width() / iw, b.height() / ih)
                    }
                    tracker.onFaces(boxes, SystemClock.elapsedRealtime())
                }
                .addOnCompleteListener(callbackExecutor) { image.close() }
        } catch (e: Exception) {
            image.close()
        }
    }

    fun close() {
        closed = true
        try { detector.close() } catch (e: Exception) { /* ignore */ }
    }
}
